from machine import I2C, Pin
i2c1 = I2C(0, scl=Pin(17), sda=Pin(16), freq=400000)       # Init I2C using I2C0 defaults, SCL=Pin(GP9), SDA=Pin(GP8), freq=400000
i2c2 = I2C(1, scl=Pin(3), sda=Pin(2), freq=400000)

print('Scan i2c bus...')
devices1 = i2c1.scan()
devices2 = i2c2.scan()

print("i2c 0")
if len(devices1) == 0:
    print("No i2c device !")
else:
    print('i2c devices found:',len(devices1))
    for device in devices1:
        print("Decimal address: ",device," | Hexa address: ",hex(device))
    
print("\ni2c 1")
if len(devices2) == 0:
    print("No i2c device !")
else:
    print('i2c devices found:',len(devices2))
    for device in devices2:
        print("Decimal address: ",device," | Hexa address: ",hex(device))
